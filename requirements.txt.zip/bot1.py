import discord
from discord.ext import commands

TOKEN = "import discord"
from discord.ext import commands

TOKEN = "MTQ0NzIwNTI4Mjk5NTM3NjM0MA.GRklOK.pJWCCWiWWkoF0ze9IvTNa_V3nwR2MB5SG35rYg"

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print("💜Audio School💜 está ONLINE!")

@bot.command()
async def ping(ctx):
    await ctx.send("Pong!")

bot.run(TOKEN)

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print("💜Audio School💜 está ONLINE!")

@bot.command()
async def ping(ctx):
    await ctx.send("Pong!")

bot.run(TOKEN)